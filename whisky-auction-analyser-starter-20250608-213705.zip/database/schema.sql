-- PostgreSQL schema
CREATE TABLE bottles (...);