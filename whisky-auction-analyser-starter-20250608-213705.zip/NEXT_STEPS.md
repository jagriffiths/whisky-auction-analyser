## Next Steps
- Add more auction site scrapers
- Build personal collection features
- Add Slack alert system
- AWS deployment script