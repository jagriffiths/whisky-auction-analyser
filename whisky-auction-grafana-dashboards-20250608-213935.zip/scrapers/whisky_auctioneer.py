# Scraper for Whisky Auctioneer
import requests
from bs4 import BeautifulSoup