
import streamlit as st
import pandas as pd
from personal_collection.import_csv import load_collection
from core.valuation import estimate_value

st.set_page_config(page_title="Whisky Auction Insights")

st.title('Whisky Auction Insights')

tabs = st.tabs(["Collection", "Valuation", "Watchlist"])

with tabs[0]:
    st.header("📦 My Whisky Collection")
    df = load_collection()
    st.dataframe(df)

with tabs[1]:
    st.header("📈 Value Estimator")
    for _, row in df.iterrows():
        estimate = estimate_value(row['name'])
        st.markdown(f"**{row['name']}** — Estimated: £{estimate['estimated_value']} → Best at: {estimate['best_auction']} → Profit: £{estimate['expected_profit']} → Month: {estimate['recommended_month']}")
