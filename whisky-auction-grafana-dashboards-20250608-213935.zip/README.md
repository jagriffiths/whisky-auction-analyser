# Whisky Auction Analyser

Project to scrape and analyse auction and retail data for whisky bottles.