# Key Architectural Decisions

- **Grafana Alloy**: Unified agent for metrics and logs, OTLP-native
- **Loki**: Cost-free log storage on EC2
- **Terraform**: Chosen for portability and repeatability
- **Playwright**: For JS-heavy auction and retail sites
- **Streamlit**: Fast GUI development with no backend overhead
