# Deployment Instructions

1. Clone the repo and install Terraform.
2. Edit terraform.tfvars or use default values.
3. Run: `terraform init && terraform apply`
4. SSH into the EC2 instance.
5. Run: `./provision.sh`
6. Visit:
   - Streamlit: http://<EC2-IP>:8501
   - Grafana: http://<EC2-IP>:3000

Default Grafana login: admin / admin
