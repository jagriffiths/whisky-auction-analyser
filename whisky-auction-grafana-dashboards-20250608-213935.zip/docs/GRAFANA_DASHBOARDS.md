# Grafana Dashboards

## Dashboards Included
- Auction Scraper Performance
- Watchlist Activity
- Collection Valuation
- System & App Health
- Log Explorer (Loki)

## Usage
Dashboards are auto-loaded using provisioning files in `/grafana/provisioning`.
Metrics are collected via Alloy and logs via Loki.

To access:
- Go to Grafana at http://<your-ec2-ip>:3000
- Login with admin / admin
