import streamlit as st

st.title('Whisky Auction Insights')
st.text('Interface coming soon...')