# Batch run for all scrapers
from scrapers import scotch_whisky_auctions, just_whisky, whisky_auction

if __name__ == '__main__':
    scotch_whisky_auctions.scrape()
    just_whisky.scrape()
    whisky_auction.scrape()