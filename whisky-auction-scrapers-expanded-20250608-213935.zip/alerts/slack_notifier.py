# Slack notifier placeholder
import os
from dotenv import load_dotenv