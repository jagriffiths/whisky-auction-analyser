# Backup & Failover Instructions

## Backups
1. RDS: Run `aws rds create-db-snapshot --db-instance-identifier your-db-name --db-snapshot-identifier backup-$(date +%F)`
2. Dashboards: Grafana auto-exports dashboards to `/backups/` via `grafana-cli --export-dashboards`.

## Restore
1. Use `aws rds restore-db-instance-from-db-snapshot` if DB fails
2. Re-deploy EC2 via Terraform and run `provision.sh`

## Failover Notes
- If RDS fails, switch Streamlit app to fallback SQLite:
  - `export DB_URL=sqlite:///fallback.db`
