# Alerting Setup

## What This Includes
- Alerts for:
  - Scrape failures
  - Missing activity
  - Log error spikes
- Slack contact point configured

## How to Use
1. Edit `slack.yaml` and replace `__SLACK_WEBHOOK_URL__` with your real Slack webhook.
2. Place these under `/etc/grafana/provisioning/alerting/` and `/contact-points/`
3. Restart Grafana: `sudo systemctl restart grafana-server`

Alerts will trigger based on Prometheus and Loki metrics via Grafana Alloy.
