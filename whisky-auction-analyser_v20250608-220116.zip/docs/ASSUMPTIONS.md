# Assumptions

- The EC2 instance is used solely for this app.
- All scraping obeys polite rate-limiting.
- Site access via public internet (no proxy/VPN).
- Watchlist entries are supplied in natural bottle names.
