# GitHub Actions Setup

Workflows include:
- Python code linting and test (black, flake8)
- Terraform fmt, validate, plan
- Automatic ZIP packaging on push to `main`

To enable:
- Push `.github/workflows/*` to your repo
- Add GitHub secrets for AWS if required
