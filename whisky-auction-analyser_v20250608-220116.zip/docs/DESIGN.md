# System Design Overview

This system is built to monitor whisky auction and retail listings, provide valuation insights, and enable live alerts.

## Components
- Streamlit (UI)
- Python scrapers
- PostgreSQL (via RDS)
- Grafana (dashboard)
- Loki (log aggregation)
- Grafana Alloy (metrics + OTLP + logging)
- Terraform (IaC)

## Design Principles
- Free Tier compliance
- Modular monitoring
- OpenTelemetry-compatible metrics and logs
