# Notifications Setup

## Slack Daily Digest
Scheduled with `cron`, sends:
- Matches in last 24h
- Errors and scrape status
- Top price movements

## Grafana Email Alerts
- SMTP via SendGrid or similar
- Config in `contact-points/email.yaml`

To use:
1. Replace placeholder SMTP and Slack webhook
2. Restart Grafana and scheduler
