# Git Branching Strategy

## Branches
- `main` – stable releases
- `dev` – current working state
- `feature/*` – individual components

## Process
- Commit each major change with message
- Use `git pull --rebase` to stay clean
- Tag versions before baseline ZIPs
