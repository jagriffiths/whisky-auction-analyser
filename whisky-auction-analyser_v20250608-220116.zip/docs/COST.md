# Cost Expectations

## AWS Free Tier (Assumed)
- EC2 t2.micro: 750 hrs/month
- RDS db.t2.micro: 750 hrs/month
- S3: 5 GB
- Data transfer out: 15 GB/month

## Potential Costs
- Long-running Grafana instances beyond 1 year
- Unused disk/storage accumulation
- Manual snapshot storage
