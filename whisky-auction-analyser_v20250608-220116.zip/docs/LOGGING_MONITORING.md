# Logging and Monitoring

## Logging
- App and scraper logs are collected from /var/log/app.log and syslog.
- Logs are streamed to Loki via Grafana Alloy.

## Monitoring
- Alloy collects:
  - CPU, memory, disk
  - Scraper metrics (matches, errors, frequency)
- View in Grafana under 'Auction App Metrics'

## Alerts
- Slack alerts via webhook
