from playwright.sync_api import sync_playwright

def scrape():
    print("Checking The Whisky Exchange...")
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        page = browser.new_page()
        page.goto("https://www.thewhiskyexchange.com/search?q=macallan")
        page.wait_for_selector(".product-card")
        bottles = []
        for item in page.query_selector_all(".product-card"):
            bottles.append({
                "bottle_name": item.inner_text().split("\n")[0],
                "price": 120,  # placeholder
                "lot_url": page.url
            })
        browser.close()
    return bottles
