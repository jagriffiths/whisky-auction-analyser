## What's Been Done
- Project scaffold
- First scraper (Whisky Auctioneer)
- Streamlit GUI shell
- Slack integration stub