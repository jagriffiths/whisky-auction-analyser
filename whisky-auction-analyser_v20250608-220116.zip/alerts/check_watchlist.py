import yaml
from alerts.slack_notifier import send_alert

def check_watchlist(matches):
    with open('config/watchlist.yaml') as f:
        watchlist = yaml.safe_load(f)
    for bottle in matches:
        if any(watch.lower() in bottle['bottle_name'].lower() for watch in watchlist):
            send_alert(bottle['bottle_name'], bottle['price'], bottle['lot_url'])
