import os
import json
import requests
from dotenv import load_dotenv

load_dotenv()

SLACK_WEBHOOK_URL = os.getenv('SLACK_WEBHOOK_URL')

def send_alert(bottle_name, price, url):
    if not SLACK_WEBHOOK_URL:
        print("[Slack] Webhook URL not configured.")
        return
    message = {
        "text": f"🔔 *Bottle Alert*: {bottle_name} just appeared for £{price}\n<{url}|View Listing>"
    }
    response = requests.post(SLACK_WEBHOOK_URL, json=message)
    print("Slack alert sent:", response.status_code)