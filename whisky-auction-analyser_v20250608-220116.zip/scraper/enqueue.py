from rq import Queue
from redis import Redis
from jobs.whiskyexchange import scrape_whiskyexchange

conn = Redis()
q = Queue(connection=conn)
q.enqueue(scrape_whiskyexchange)
print("Job enqueued: scrape_whiskyexchange")
