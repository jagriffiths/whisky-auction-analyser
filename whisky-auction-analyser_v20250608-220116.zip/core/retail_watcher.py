from scrapers.retail import twe, royal_mile, wee_dram
from alerts.check_watchlist import check_watchlist

def run():
    all_results = []
    all_results.extend(twe.scrape())
    all_results.extend(royal_mile.scrape())
    all_results.extend(wee_dram.scrape())
    check_watchlist(all_results)

if __name__ == '__main__':
    run()
