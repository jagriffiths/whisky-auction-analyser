# Unified data model for all scraped auction bottles
from dataclasses import dataclass

@dataclass
class ScrapedBottle:
    bottle_name: str
    distillery: str
    volume_ml: int
    abv: float
    age: int
    price: float
    currency: str
    date_sold: str
    auction_site: str
    lot_url: str
    buyer_fee_percent: float
    seller_fee_percent: float