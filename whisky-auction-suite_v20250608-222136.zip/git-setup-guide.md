# Git Setup Guide for Whisky Auction Suite

## 📁 Project Structure
See full layout under `whisky-auction-suite/`. Key folders:
- `app/`, `gui/`, `tests/`, `infra/`, `dashboards/`, `docs/`

## 🗂 Branch Strategy
| Branch         | Purpose                                  |
|----------------|-------------------------------------------|
| `main`         | Stable, production-ready releases         |
| `dev`          | Active development                        |
| `feature/*`    | Feature-specific branches                 |
| `test/*`       | Testing and QA                            |

## 🧑‍💻 Manual Git Init & Push
```bash
git init
git remote add origin https://github.com/jagriffiths/whisky-auction-suite.git
git checkout -b main
git add .
git commit -m "Initial commit - full whisky auction suite baseline"
git push -u origin main
```

## 🧪 Create Dev + Feature Branches
```bash
git checkout -b dev
git push -u origin dev

git checkout -b feature/ml-pricing
```

## ✅ GitHub Actions (Optional)
`.github/workflows/test.yml` runs:
- `pytest`
- Publishes CI test results

## 🧾 Notes
- Don’t commit `.env` — use `.env.example` or GitHub secrets
- Always branch from `dev`, then PR into `main` for stable builds