def scrape():
    print("Checking Royal Mile Whiskies...")
    return []  # placeholder
