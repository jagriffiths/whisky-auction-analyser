def scrape():
    print("Checking The Wee Dram...")
    return []  # placeholder
