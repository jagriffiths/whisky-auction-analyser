import webbrowser

def open_checkout(url):
    print(f"Opening checkout URL: {url}")
    webbrowser.open(url)
